<template>
  <div id="app">
    <HeaderComponent />
    <main>
      <transition name="fade" mode="out-in">
        <router-view />
      </transition>
    </main>
  </div>
</template>

<script>
// Chargement du composant de l'en-tête (Header)
import HeaderComponent from './components/Header.vue';

export default {
  name: 'App',
  components: {
    HeaderComponent
  }
};
</script>

<style>
/* RESET GLOBAL */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* FOND GENERAL */
body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background: #f6f8fa;
  color: #333;
}

/* CONTENEUR PRINCIPAL */
#app {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* ZONE PRINCIPALE DE CONTENU */
main {
  flex-grow: 1;
  padding: 20px;
  animation: slideFade 0.4s ease-in-out;
}

/* ANIMATION DE ROUTE */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.4s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

/* ANIMATION SLIDE DOUX */
@keyframes slideFade {
  0% {
    opacity: 0;
    transform: translateY(20px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
