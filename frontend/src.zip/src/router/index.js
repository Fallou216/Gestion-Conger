import { createRouter, createWebHistory } from 'vue-router';

// Vues publiques
import Login    from '../views/Login.vue';
import Register from '../views/Register.vue';

// Vues employé
import DashboardEmploye from '../views/DashboardEmploye.vue';
import MesDemandes      from '../views/MesDemandes.vue';

// Vues responsable
import DashboardResponsable from '../views/DashboardResponsable.vue';
import Services             from '../views/Services.vue';
import Utilisateurs         from '../views/Utilisateurs.vue';

const routes = [

  // ── PUBLIQUES ──────────────────────────────────
  { path: '/',         name: 'Login',    component: Login    },
  { path: '/register', name: 'Register', component: Register },

  // ── EMPLOYÉ ────────────────────────────────────
  {
    path: '/employe',
    redirect: '/employe/dashboard',
    meta: { requiresAuth: true, role: 'employe' }
  },
  {
    path: '/employe/dashboard',
    name: 'DashboardEmploye',
    component: DashboardEmploye,
    meta: { requiresAuth: true, role: 'employe' }
  },
  {
    path: '/employe/mes-demandes',
    name: 'MesDemandes',
    component: MesDemandes,
    meta: { requiresAuth: true, role: 'employe' }
  },

  // ── RESPONSABLE ────────────────────────────────
  {
    path: '/responsable',
    redirect: '/responsable/demandes',
    meta: { requiresAuth: true, role: 'responsable' }
  },
  {
    path: '/responsable/demandes',
    name: 'DashboardResponsable',
    component: DashboardResponsable,
    meta: { requiresAuth: true, role: 'responsable' }
  },
  {
    path: '/services',
    name: 'Services',
    component: Services,
    meta: { requiresAuth: true, role: 'responsable' }
  },
  {
    path: '/utilisateurs',
    name: 'Utilisateurs',
    component: Utilisateurs,
    meta: { requiresAuth: true, role: 'responsable' }
  },

  // ── FALLBACK ───────────────────────────────────
  { path: '/:catchAll(.*)', redirect: '/' }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

// ── GUARD GLOBAL ───────────────────────────────
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token');
  const role  = localStorage.getItem('role');

  if (to.meta.requiresAuth) {
    if (!token) return next({ name: 'Login' });

    if (to.meta.role && to.meta.role !== role) {
      if (role === 'employe')     return next({ name: 'DashboardEmploye' });
      if (role === 'responsable') return next({ name: 'DashboardResponsable' });
      return next({ name: 'Login' });
    }
  } else {
    if ((to.name === 'Login' || to.name === 'Register') && token) {
      if (role === 'employe')     return next({ name: 'DashboardEmploye' });
      if (role === 'responsable') return next({ name: 'DashboardResponsable' });
    }
  }

  next();
});

export default router;