<template>
  <div class="soumettre-container">
    <div class="form-box">
      <h2>Soumettre une demande de congé</h2>

      <form @submit.prevent="soumettreDemande" enctype="multipart/form-data">
        <label>Date de début</label>
        <input type="date" v-model="dateDebut" required />

        <label>Date de fin</label>
        <input type="date" v-model="dateFin" required />

        <label>Motif</label>
        <textarea v-model="motif" placeholder="Ex: vacances, maladie..." required></textarea>

        <label>Pièce jointe (facultatif)</label>
        <input type="file" @change="handleFile" />

        <button type="submit">Envoyer la demande</button>

        <p class="message" v-if="message">{{ message }}</p>
        <p class="error" v-if="erreur">{{ erreur }}</p>
      </form>
    </div>
  </div>
</template>

<script>
import axios from '../axios';

export default {
  data() {
    return {
      dateDebut: '',
      dateFin: '',
      motif: '',
      fichier: null,
      message: '',
      erreur: ''
    };
  },
  methods: {
    handleFile(event) {
      this.fichier = event.target.files[0];
    },

    async soumettreDemande() {
      this.message = '';
      this.erreur = '';

      const formData = new FormData();
      formData.append('dateDebut', this.dateDebut);
      formData.append('dateFin', this.dateFin);
      formData.append('motif', this.motif);
      if (this.fichier) {
        formData.append('fichier', this.fichier);
      }

      try {
        await axios.post('/conges', formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
        this.message = 'Demande envoyée avec succès.';
        this.dateDebut = '';
        this.dateFin = '';
        this.motif = '';
        this.fichier = null;
      } catch (err) {
        this.erreur = err.response?.data?.message || 'Erreur lors de l’envoi.';
      }
    }
  }
};
</script>

<style scoped>
.soumettre-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 85vh;
  padding: 20px;
  background: linear-gradient(to right, #e3f2fd, #fff);
}

.form-box {
  background: white;
  padding: 30px;
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 500px;
  transition: all 0.3s ease-in-out;
}

.form-box:hover {
  transform: scale(1.01);
}

label {
  font-weight: bold;
  margin-top: 15px;
  display: block;
}

input[type="date"],
textarea,
input[type="file"] {
  width: 100%;
  padding: 10px;
  margin: 10px 0 15px;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 14px;
}

textarea {
  resize: vertical;
  min-height: 80px;
}

button {
  width: 100%;
  background-color: #0d6efd;
  color: white;
  padding: 12px;
  border: none;
  font-weight: bold;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

button:hover {
  background-color: #0b5ed7;
}

.message {
  color: green;
  margin-top: 15px;
  text-align: center;
}

.error {
  color: red;
  margin-top: 15px;
  text-align: center;
}

@media (max-width: 600px) {
  .form-box {
    padding: 20px;
  }
}
</style>
