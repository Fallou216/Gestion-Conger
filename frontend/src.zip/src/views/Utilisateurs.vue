<template>
  <div class="utilisateurs-container">
    <h2><i class="fas fa-users-cog"></i> Gestion des employés</h2>

    <!-- 🔍 Recherche -->
    <input v-model="recherche" placeholder="Rechercher par nom ou prénom..." class="search-bar" />

    <!-- 🆕 Formulaire de création -->
    <form class="form-creation" @submit.prevent="ajouterUtilisateur">
      <h3><i class="fas fa-user-plus"></i> Ajouter un nouvel employé</h3>
      <div class="form-group">
        <input v-model="formAjout.nom" placeholder="Nom" required />
        <input v-model="formAjout.prenom" placeholder="Prénom" required />
        <input v-model="formAjout.email" placeholder="Email" required type="email" />
        <input v-model="formAjout.motDePasse" placeholder="Mot de passe" required type="password" />
      </div>
      <div class="form-group">
        <select v-model="formAjout.role" required>
          <option disabled value="">-- Rôle --</option>
          <option value="employe">Employé</option>
          <option value="responsable">Responsable</option>
        </select>

        <select v-model="formAjout.service">
          <option value="">-- Aucun service --</option>
          <option v-for="s in services" :key="s._id" :value="s._id">{{ s.nom }}</option>
        </select>
        <button type="submit" class="btn green">Ajouter</button>
      </div>
    </form>

    <p class="error" v-if="erreur">{{ erreur }}</p>

    <!-- 📋 Liste des utilisateurs -->
    <table class="table-utilisateurs">
      <thead>
        <tr>
          <th>Nom</th>
          <th>Prénom</th>
          <th>Email</th>
          <th>Rôle</th>
          <th>Service</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="user in utilisateursFiltres" :key="user._id">
          <!-- 📝 Mode édition -->
          <template v-if="editId === user._id">
            <td><input v-model="formEdit.nom" /></td>
            <td><input v-model="formEdit.prenom" /></td>
            <td><input v-model="formEdit.email" /></td>
            <td>
              <select v-model="formEdit.role">
                <option value="employe">Employé</option>
                <option value="responsable">Responsable</option>
              </select>
            </td>
            <td>
              <select v-model="formEdit.service">
                <option value="">-- Aucun --</option>
                <option v-for="s in services" :key="s._id" :value="s._id">{{ s.nom }}</option>
              </select>
            </td>
            <td>
              <button @click="validerEdition(user._id)" class="btn green"><i class="fas fa-check"></i></button>
              <button @click="annulerEdition()" class="btn red"><i class="fas fa-times"></i></button>
            </td>
          </template>

          <!-- 👁️ Mode affichage -->
          <template v-else>
            <td>{{ user.nom }}</td>
            <td>{{ user.prenom }}</td>
            <td>{{ user.email }}</td>
            <td>{{ user.role }}</td>
            <td>{{ user.service?.nom || '-' }}</td>
            <td>
              <button @click="activerEdition(user)" class="btn blue"><i class="fas fa-edit"></i></button>
              <button @click="supprimerUtilisateur(user._id)" class="btn red"><i class="fas fa-trash-alt"></i></button>
            </td>
          </template>
        </tr>
      </tbody>
    </table>

    <p v-if="!utilisateursFiltres.length">Aucun utilisateur trouvé.</p>
  </div>
</template>

<script>
import axios from '../axios';

export default {
  data() {
    return {
      utilisateurs: [],
      services: [],
      recherche: '',
      erreur: '',
      editId: null,
      formEdit: {},
      formAjout: {
        nom: '',
        prenom: '',
        email: '',
        motDePasse: '',
        role: '',
        service: ''
      }
    };
  },
  computed: {
    utilisateursFiltres() {
      const term = this.recherche.toLowerCase();
      return this.utilisateurs.filter(
        u =>
          u.nom.toLowerCase().includes(term) ||
          u.prenom.toLowerCase().includes(term)
      );
    }
  },
  methods: {
    async chargerUtilisateurs() {
      try {
        const res = await axios.get('/users');
        this.utilisateurs = res.data;
      } catch (err) {
        this.erreur = 'Impossible de charger les utilisateurs.';
      }
    },
    async chargerServices() {
      try {
        const res = await axios.get('/services');
        this.services = res.data;
      } catch (err) {
        this.erreur = 'Impossible de charger les services.';
      }
    },
    async ajouterUtilisateur() {
      try {
        await axios.post('/users', this.formAjout);
        this.formAjout = { nom: '', prenom: '', email: '', motDePasse: '', role: '', service: '' };
        this.chargerUtilisateurs();
      } catch (err) {
        alert(err.response?.data?.message || 'Erreur ajout utilisateur');
      }
    },
    activerEdition(user) {
      this.editId = user._id;
      this.formEdit = {
        nom: user.nom,
        prenom: user.prenom,
        email: user.email,
        role: user.role,
        service: user.service?._id || ''
      };
    },
    annulerEdition() {
      this.editId = null;
      this.formEdit = {};
    },
    async validerEdition(id) {
      try {
        await axios.put(`/users/${id}`, this.formEdit);
        this.editId = null;
        this.chargerUtilisateurs();
      } catch (err) {
        alert('Erreur lors de la mise à jour.');
      }
    },
    async supprimerUtilisateur(id) {
      if (!confirm('Supprimer cet utilisateur ?')) return;
      try {
        await axios.delete(`/users/${id}`);
        this.chargerUtilisateurs();
      } catch (err) {
        alert('Erreur lors de la suppression.');
      }
    }
  },
  mounted() {
    this.chargerUtilisateurs();
    this.chargerServices();
  }
};
</script>

<style scoped>
.utilisateurs-container {
  max-width: 96%;
  margin: 30px auto;
  background: #fff;
  padding: 25px 30px;
  border-radius: 12px;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
  animation: fadein 0.4s ease;
}

h2 {
  text-align: center;
  color: #0d6efd;
  margin-bottom: 15px;
}

.search-bar {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border-radius: 6px;
  border: 1px solid #ccc;
}

.table-utilisateurs {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}

.table-utilisateurs th,
.table-utilisateurs td {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid #eee;
}

.table-utilisateurs th {
  background: #f1f1f1;
}

.form-creation {
  background: #f9f9f9;
  padding: 15px 20px;
  margin-bottom: 20px;
  border-radius: 8px;
}

.form-group {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 10px;
}

input,
select {
  padding: 10px;
  border-radius: 5px;
  border: 1px solid #ccc;
  flex: 1 1 200px;
}

button {
  padding: 10px 14px;
  font-weight: 600;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}

.btn {
  font-size: 14px;
  margin-right: 6px;
  color: white;
}

.btn.red {
  background-color: #dc3545;
}

.btn.green {
  background-color: #198754;
}

.btn.blue {
  background-color: #0d6efd;
}

.error {
  color: red;
  margin-bottom: 10px;
  text-align: center;
}

@keyframes fadein {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
