<template>
  <div class="services-container">
    <h2><i class="fas fa-building"></i> Gestion des Services</h2>

    <form @submit.prevent="ajouterService" class="form-service">
      <input v-model="nouveauService" placeholder="Nom du service" required />
      <button type="submit">
        <i class="fas fa-plus-circle"></i> Ajouter
      </button>
    </form>

    <ul class="service-list">
      <li v-for="service in services" :key="service._id" class="service-item">
        <div class="service-nom">
          <i class="fas fa-sitemap"></i> {{ service.nom }}
        </div>

        <div class="service-actions">
          <button @click="editerService(service)">
            <i class="fas fa-edit"></i>
          </button>
          <button @click="supprimerService(service._id)">
            <i class="fas fa-trash-alt"></i>
          </button>
        </div>
      </li>
    </ul>

    <!-- Modal d’édition -->
    <div v-if="serviceEnEdition" class="modal">
      <div class="modal-content">
        <h3>Modifier le service</h3>
        <input v-model="serviceEnEdition.nom" placeholder="Nom du service" />
        <div class="modal-buttons">
          <button @click="validerModification">
            <i class="fas fa-check"></i> Valider
          </button>
          <button @click="annulerModification">
            <i class="fas fa-times"></i> Annuler
          </button>
        </div>
      </div>
    </div>

    <p class="error" v-if="erreur">{{ erreur }}</p>
  </div>
</template>

<script>
import axios from '../axios';

export default {
  data() {
    return {
      services: [],
      nouveauService: '',
      serviceEnEdition: null,
      erreur: ''
    };
  },
  methods: {
    async chargerServices() {
      try {
        const res = await axios.get('/services');
        this.services = res.data;
      } catch (err) {
        this.erreur = 'Impossible de charger les services.';
      }
    },
    async ajouterService() {
      try {
        await axios.post('/services', { nom: this.nouveauService });
        this.nouveauService = '';
        this.chargerServices();
      } catch (err) {
        this.erreur = err.response?.data?.message || 'Erreur lors de l’ajout.';
      }
    },
    editerService(service) {
      this.serviceEnEdition = { ...service };
    },
    async validerModification() {
      try {
        await axios.put(`/services/${this.serviceEnEdition._id}`, {
          nom: this.serviceEnEdition.nom
        });
        this.serviceEnEdition = null;
        this.chargerServices();
      } catch (err) {
        this.erreur = err.response?.data?.message || 'Erreur modification.';
      }
    },
    annulerModification() {
      this.serviceEnEdition = null;
    },
    async supprimerService(id) {
      if (!confirm('Confirmer la suppression de ce service ?')) return;
      try {
        await axios.delete(`/services/${id}`);
        this.chargerServices();
      } catch (err) {
        this.erreur = 'Erreur lors de la suppression.';
      }
    }
  },
  mounted() {
    this.chargerServices();
  }
};
</script>

<style scoped>
.services-container {
  max-width: 700px;
  margin: 30px auto;
  background: #fff;
  padding: 30px;
  border-radius: 12px;
  box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
}

h2 {
  color: #0d6efd;
  margin-bottom: 25px;
  text-align: center;
  font-size: 1.8rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
}

.form-service {
  display: flex;
  gap: 10px;
  margin-bottom: 25px;
}

.form-service input {
  flex: 1;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 6px;
}

.form-service button {
  background-color: #0d6efd;
  color: white;
  border: none;
  padding: 10px 14px;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 6px;
}

.form-service button:hover {
  background-color: #0b5ed7;
}

.service-list {
  list-style: none;
  padding: 0;
}

.service-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px;
  border-bottom: 1px solid #eee;
  font-weight: 600;
}

.service-actions button {
  background: none;
  border: none;
  font-size: 18px;
  margin-left: 10px;
  cursor: pointer;
  color: #0d6efd;
  transition: transform 0.2s;
}

.service-actions button:hover {
  transform: scale(1.2);
  color: #0a58ca;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.45);
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-content {
  background: white;
  padding: 25px;
  border-radius: 10px;
  width: 90%;
  max-width: 400px;
  box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
}

.modal-buttons {
  display: flex;
  justify-content: space-between;
  margin-top: 15px;
}

.modal-buttons button {
  flex: 1;
  margin: 0 5px;
  padding: 10px;
  font-weight: 600;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  color: white;
}

.modal-buttons button:first-child {
  background-color: #198754;
}

.modal-buttons button:last-child {
  background-color: #dc3545;
}

.error {
  color: red;
  margin-top: 10px;
  text-align: center;
}
</style>
